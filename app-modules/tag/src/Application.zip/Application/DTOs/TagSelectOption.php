<?php

class TagSelectOption
{
    public function __construct(
        public int $value,
        public string $label,
    ) {}
}
